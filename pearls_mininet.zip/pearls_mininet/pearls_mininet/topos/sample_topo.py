from mininet.topo import Topo
from mininet.net import Mininet
from mininet.util import dumpNodeConnections
from mininet.cli import CLI

class sample_topo(Topo):
    
    def build(self):
        pass
        #switch = self.addSwitch('switchname')
        #host = self.addHost('hostname')
        #self.addLink(hostname,switchname)

topos = {'part1' : sample_topo}

if __name__ == '__main__':
    t = sample_topo()
    net = Mininet (topo=t)
    net.start()
    CLI(net)
    net.stop()
