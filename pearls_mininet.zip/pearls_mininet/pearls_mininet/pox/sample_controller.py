from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.revent import *
from pox.lib.addresses import IPAddr
from pox.messenger import *
from pox.core import core
import pox.openflow.libopenflow_01 as of
from pox.lib.util import dpid_to_str, str_to_dpid
from pox.lib.util import str_to_bool


log = core.getLogger()

class Controller (object):
  """
  A Controller object is created for each switch that connects.
  A Connection object for that switch is passed to the __init__ function.
  """
  def __init__ (self, connection):
    # Keep track of the connection to the switch so that we can
    # send it messages!
    self.connection = connection

    # This binds our PacketIn event listener
    connection.addListeners(self)

    #add switch rules here

  def _handle_PacketIn (self, event):
    """
    Packets not handled by the router rules will be
    forwarded to this method to be handled by the controller
    """

    packet = event.parsed # This is the parsed packet data.
    if not packet.parsed:
      log.warning("Ignoring incomplete packet")
      return

    packet_in = event.ofp # The actual ofp_packet_in message.
    print ("Unhandled packet :" + str(packet.dump()))

    def _all_dependencies_met (self):
      # create messenger channel
      chat_channel = core.MessengerNexus.get_channel("controller")
      # the main method to call when a message is received in channel "controller"
      def handle_chat (event, msg):
        m = str(msg.get("msg"))
        if m == "close":
            log.debug("Close message received.")

         
      # setup event handler in pox
      chat_channel.addListener(MessageReceived, handle_chat)

def launch ():
  """
  Starts the component
  """
  def start_switch (event):
    log.debug("Controlling %s" % (event.connection,))
    Controller(event.connection)
  core.openflow.addListenerByName("ConnectionUp", start_switch)
